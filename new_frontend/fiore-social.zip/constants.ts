// This file contains constants used throughout the application.

// Centralized API endpoint for the Fiore backend.
export const API_BASE_URL = 'https://fastapi.fiorejoy.com';

// Dynamically create the WebSocket URL based on the API endpoint.
// This ensures it uses 'wss://' for secure 'https://' connections.
const wsProtocol = API_BASE_URL.startsWith('https') ? 'wss' : 'ws';
const wsHost = API_BASE_URL.replace(/^https?:\/\//, '');
export const WEBSOCKET_URL = `${wsProtocol}://${wsHost}`;


// API key for the Fiore backend.
// NOTE: For production, this should come from environment variables.
export const FIORE_API_KEY = '8vhye983h48fh38sh8hs';

// A predefined list of user interests for profiles and communities.
export const INTERESTS = [
  'Technology',
  'Gaming',
  'Music',
  'Art',
  'Sports',
  'Reading',
  'Travel',
  'Movies',
  'Cooking',
  'Fashion',
  'Fitness',
  'Photography',
];
